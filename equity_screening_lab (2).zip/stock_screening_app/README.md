# Equity Screening Lab

A Streamlit app for a three-stage equity screening workflow with per-stage tables, optional industry demeaning, independent ratio weights, configurable elimination percentages, and industry-level portfolio target weights.

## Important data note

The included `sample_700_companies.csv` is **synthetic demonstration data**, not real company financial information. Upload a verified CSV of real company fundamentals before using this for actual company comparisons. The app deliberately labels the demo data and does not represent it as real.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy

Upload the contents of this folder to a GitHub repository. In Streamlit Community Cloud, create an app from that repository and select `app.py` as the entrypoint. Official guide: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy

## Data columns

Required: `Company, Ticker, Sector, Industry, STA, SNOA, Z_Score, GPA, BTM, CFOA`.

For automatic seven-year MS/MG calculations, also provide eight annual margin observations: `Margin_Tminus7, Margin_Tminus6, Margin_Tminus5, Margin_Tminus4, Margin_Tminus3, Margin_Tminus2, Margin_Tminus1, Margin_T`. These yield seven annual growth rates.

- MS = arithmetic average of annual margin growth rates / sample standard deviation of those rates.
- MG = `(ending margin / starting margin)^(1/7) - 1`, requiring positive start/end values.
- MM = `max(percentile(MS), percentile(MG))`.

## Screening behavior

- Stage 1: STA and SNOA low is good; Z-score high is good.
- Stage 2: MS and MG displayed/ranked individually; MM is also calculated. Ratio weights control the MS/MG component ranks.
- Stage 3: GPA, BTM, CFOA high is good by default. Confirm BTM and ratio directions against your course method.
- Optional industry demeaning is available separately for each stage.
- Ratio weights range from 0 to 5; zero excludes a ratio from the weighted stage score.
- The portfolio starts with equal target weights across industries represented among the final survivors. Users can edit industry targets; each industry allocation is divided equally among its surviving companies.

This is an educational tool, not investment advice. Verify financial metric definitions, fiscal-year alignment, data coverage, and source licensing.
